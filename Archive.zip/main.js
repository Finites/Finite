var table = document.getElementById("finite-differences");
var rows = 5;
var exponent = 6;
var dataSet = [];

function cloneRow() {
   var row = document.getElementById("row"); // find row to copy
   var table = document.getElementById("finite-differences"); // find table to append to
   var clone = row.cloneNode(true); // copy children too
   table.childNodes[1].appendChild(clone); // add new row to end of table
}

function generateRows() {
   var rowCount = 0;
   while (rowCount != (rows- 1)) {
      cloneRow();
      rowCount += 1;
   }
}

function reloadRowData() {
   console.log("Reload: Before: " + dataSet);
   generateDataSet();
   console.log("After: " + dataSet);
   updateTable();
}

function generateDataSet() {
   dataSet = [];
   var yColumn = document.getElementsByClassName("Y-Input");
   for (var i=0; i<yColumn.length; i++) {
      var yInput = yColumn[i];
      dataSet.push(parseInt(yInput.value));
   }
}
/*
function updateTable() {
   var rows = table.childNodes[1];
   for (var i=0; i<rows.childNodes.length;i++) {
      var row = rows.childNodes[i];
      if (row.id != "row") { continue }

      var localExponent = 1;
      var localColumn = 5;
      console.log("While: " + dataSet);
      while (localExponent <= exponent) {
         var cell = row.childNodes[localColumn];
         var data = findDiference(exponent, dataSet);
         cell.innerHTML = data[i];
         localExponent += 1;
         localColumn += 2;
      }
   }
}
*/

function updateTable() {
   var fml = [2, 4, 6, 8, 10];
   var rows = table.childNodes[1];
   for (var i=0; i<rows.childNodes.length;i++) {
      var row = rows.childNodes[i];
      if (row.id != "row") { continue }

      var localExponent = 1;
      var localColumn = 5;
      console.log("While: " + fml);
      while (localExponent <= exponent) {
         var cell = row.childNodes[localColumn];
         console.log("are you ducking nil " + fml);
         var data = findDiference(exponent, fml);
         cell.innerHTML = fml[localExponent - 1];
         localExponent += 1;
         localColumn += 2;
      }
   }
}


function findDiference(exponent, data) {
   console.log("yooooo " + data);
   var localExponent = 1;
   var locolData = data;
   while (exponent != localExponent) {
      for (var i=0; i<locolData.length;i++) {
         if (i != (locolData.length - 1)) {
            var firstNumber = locolData[i];
            var secondNumber = locolData[i + 1];
            var difference = secondNumber - firstNumber;
            locolData.splice(i, 1, difference);
         } else {
            locolData.pop();
            break;
         }
      }
      localExponent += 1;
   }
   return locolData
}

generateRows();
